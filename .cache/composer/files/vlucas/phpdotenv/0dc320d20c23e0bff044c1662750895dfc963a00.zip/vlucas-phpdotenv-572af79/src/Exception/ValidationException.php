<?php

namespace Dotenv\Exception;

use RuntimeException;

class ValidationException extends RuntimeException implements ExceptionInterface
{
    //
}
